package NGPlayerTools;

/**
 * Created by Nils on 13.05.2017.
 */
public enum Direction {
    Left,
    Right,
    Up,
    Down,
    UpLeft,
    UpRight,
    DownRight,
    DownLeft
}
