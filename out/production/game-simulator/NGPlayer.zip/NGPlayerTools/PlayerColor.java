package NGPlayerTools;

/**
 * Created by Nils on 30.04.2017.
 */
public enum PlayerColor {
    Own,
    Rival,
    Empty
}
