package NGPlayerTools;

/**
 * Created by Nils on 10.05.2017.
 */
public enum ScanDirection {
    UpperLeftToLowerRight,
    LeftToRight, TopToBottom, LowerRightToUpperLeft, RightToLeft, BottomToTop, LowerLeftToUpperRight, UpperRightToLowerLeft
}
